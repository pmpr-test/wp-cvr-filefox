<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fc9e37be             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\166\x65\156\x64\157\162\x2f\141\x75\164\x6f\x6c\x6f\x61\x64\56\x70\x68\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\x68\x70" => "\67\56\x32", "\167\x70" => "\65\x2e\x32", "\x74\151\x74\x6c\x65" => __("\x46\151\154\145\x66\157\x78"), "\x66\x69\154\x65" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\x65\x71\165\151\162\x65\155\x65\156\x74\x73\x20\144\151\144\40\156\x6f\164\40\x70\141\163\163\x20\146\x6f\162\40\164\x68\x65\40\143\x6f\x76\x65\x72"); }
