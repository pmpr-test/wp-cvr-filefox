<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc9c93b4c7             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\x76\145\x6e\144\157\162\x2f\141\165\164\x6f\154\157\x61\144\56\160\150\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\x68\x70" => "\67\56\x32", "\167\160" => "\x35\56\x32", "\164\151\164\154\x65" => __("\x46\x69\154\x65\146\x6f\x78"), "\146\x69\154\145" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\145\x71\165\x69\x72\x65\x6d\145\156\164\x73\x20\x64\151\x64\x20\x6e\x6f\164\40\x70\x61\163\x73\40\x66\157\162\40\164\150\145\x20\x63\157\166\145\x72"); }
