<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc22266c29             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\x76\x65\156\x64\x6f\x72\57\x61\165\164\157\154\x6f\141\144\x2e\x70\x68\x70"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\160\150\160" => "\x37\x2e\62", "\x77\160" => "\65\x2e\x32", "\x74\x69\164\154\x65" => __("\106\x69\154\145\146\x6f\x78"), "\146\x69\x6c\x65" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\x52\x65\x71\x75\x69\162\145\x6d\x65\x6e\x74\163\x20\144\151\x64\40\156\x6f\164\x20\x70\x61\x73\x73\x20\146\157\162\40\164\150\145\40\143\157\x76\x65\x72"); }
