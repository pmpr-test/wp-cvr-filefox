<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523fd154c             |
    |_______________________________________|
*/
 require_once __DIR__ . "\57\166\x65\x6e\144\x6f\162\x2f\141\165\164\157\x6c\x6f\x61\x64\56\160\x68\x70"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\x70\x68\160" => "\67\x2e\x32", "\x77\160" => "\x35\x2e\62", "\x74\151\x74\154\145" => __("\x46\x69\x6c\x65\146\x6f\170"), "\146\x69\x6c\x65" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\x52\145\161\x75\x69\x72\145\x6d\145\x6e\x74\x73\x20\144\x69\x64\x20\x6e\157\164\x20\160\x61\163\x73\x20\x66\x6f\x72\40\x74\150\x65\40\143\x6f\166\x65\162"); }
