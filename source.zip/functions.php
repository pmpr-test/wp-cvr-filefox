<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fdcfddc8be             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\x76\x65\156\x64\157\x72\57\x61\165\164\157\x6c\x6f\x61\x64\x2e\160\x68\x70"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\x70\150\x70" => "\67\56\62", "\167\160" => "\x35\x2e\x32", "\164\x69\x74\154\145" => __("\106\151\154\145\146\x6f\170"), "\146\151\x6c\145" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\145\161\165\x69\x72\x65\155\x65\156\164\x73\40\144\x69\144\x20\156\157\164\x20\x70\141\163\x73\40\x66\x6f\x72\x20\164\150\145\40\143\157\x76\x65\x72"); }
