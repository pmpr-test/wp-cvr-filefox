<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d8352db942             |
    |_______________________________________|
*/
 require_once __DIR__ . "\x2f\166\x65\x6e\x64\157\x72\57\141\x75\164\157\154\x6f\141\x64\56\x70\x68\160"; use Pmpr\Cover\Filefox\Filefox; $ooggiaqasyawsuks = Filefox::iwgqamekocwaigci(); $qcsieyqqegaoocks = Filefox::haqswuugoswcyoia(); $yqicqqkokawiosom = $ooggiaqasyawsuks->essaugkeosgskqme()->sskmceyamwugkaii(["\x70\150\160" => "\x37\x2e\x32", "\x77\x70" => "\x35\x2e\x32", "\164\x69\x74\154\x65" => __("\x46\x69\154\x65\x66\157\170"), "\x66\151\154\145" => __FILE__]); if ($yqicqqkokawiosom) { if (class_exists(Filefox::class)) { $giyigwuwegmygqau = Filefox::symcgieuakksimmu(); } } else { wp_die("\122\x65\x71\x75\151\x72\x65\155\145\x6e\x74\x73\x20\144\151\144\40\x6e\157\164\x20\160\x61\163\163\40\x66\157\x72\x20\x74\150\145\40\x63\157\x76\x65\162"); }
