<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac858dc9156             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
