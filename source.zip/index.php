<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843e9d5ed6b2             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
