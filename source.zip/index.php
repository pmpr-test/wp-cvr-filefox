<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b7aac431b1f             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
