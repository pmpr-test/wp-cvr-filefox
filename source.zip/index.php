<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b7a85a707cd             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
