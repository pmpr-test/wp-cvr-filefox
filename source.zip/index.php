<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68aed622e3d88             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
