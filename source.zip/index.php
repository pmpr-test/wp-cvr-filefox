<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68056a6232320             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
