<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6886839761c0f             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
