<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68868aebdcbe6             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
