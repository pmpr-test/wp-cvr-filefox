<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cecad8a1133             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
