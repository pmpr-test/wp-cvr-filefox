<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687f52c681cf3             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
