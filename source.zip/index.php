<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d4b46d111             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
