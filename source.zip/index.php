<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a71e8c8605b             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
