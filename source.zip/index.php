<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843eaa10f854             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
