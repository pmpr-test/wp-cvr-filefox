<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e93408155f5             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
