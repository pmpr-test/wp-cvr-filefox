<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169d894d50c             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
