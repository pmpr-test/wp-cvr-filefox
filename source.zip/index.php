<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687f56c97c355             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
