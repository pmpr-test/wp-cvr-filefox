<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a48ec00e6bc             |
    |_______________________________________|
*/
 pmpr_do_action('init_cover');
