<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689e5f2de985f             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
