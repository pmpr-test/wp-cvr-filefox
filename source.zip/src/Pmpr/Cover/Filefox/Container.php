<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e5a4f86e76d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; abstract class Container extends BaseClass { use CommonTrait; }
