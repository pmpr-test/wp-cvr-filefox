<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bcab70d793             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\156\137\x69\x6e\x69\164", [$this, "\171\145\171\151\x67\x75\171\145\x67\x6d\155\x79\165\x73\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\x74\x65\162\151\x61\x6c\x5f\155\x65\x67\141\155\x65\156\165\x5f\x66\151\145\x6c\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\x75\x72\141\x6c\40\116\x61\155\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\164\x65\x72\151\141\x6c")->register(); } }
