<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fdcfddc8be             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\x64\155\151\x6e\137\x69\x6e\151\164", [$this, "\x79\145\x79\x69\x67\165\171\x65\x67\x6d\x6d\171\165\x73\x65\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\164\x65\162\x69\x61\154\x5f\x6d\x65\x67\x61\x6d\x65\x6e\165\x5f\x66\151\145\x6c\x64\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\154\x75\x72\141\154\x20\116\141\x6d\x65", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\x74\145\162\151\x61\x6c")->register(); } }
