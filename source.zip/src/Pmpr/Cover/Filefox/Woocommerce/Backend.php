<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d64d6c6e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\155\x69\156\x5f\151\156\x69\x74", [$this, "\171\145\171\x69\147\165\x79\145\x67\155\x6d\x79\x75\x73\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\164\145\162\151\141\154\137\x6d\x65\147\x61\x6d\x65\x6e\x75\x5f\x66\x69\x65\x6c\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\165\162\141\x6c\40\116\x61\x6d\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\141\x74\x65\162\151\x61\154")->register(); } }
