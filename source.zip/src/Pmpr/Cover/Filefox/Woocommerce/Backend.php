<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915126a65d4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\x69\156\x5f\x69\x6e\x69\164", [$this, "\171\x65\171\x69\x67\x75\171\x65\147\x6d\x6d\171\165\x73\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\x74\x65\162\x69\141\154\137\x6d\x65\x67\141\x6d\145\156\165\137\x66\151\145\154\x64\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\x6c\165\162\x61\x6c\40\x4e\x61\x6d\x65", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\164\145\162\151\x61\x6c")->register(); } }
