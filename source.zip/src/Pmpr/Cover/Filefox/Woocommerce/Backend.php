<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d8352db942             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\151\156\137\x69\156\151\164", [$this, "\171\x65\171\x69\x67\165\171\145\147\x6d\155\171\x75\x73\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\164\x65\x72\151\141\x6c\x5f\x6d\145\x67\141\x6d\145\x6e\x75\x5f\146\151\x65\x6c\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\154\x75\x72\x61\154\x20\116\x61\155\145", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\164\145\162\151\x61\x6c")->register(); } }
