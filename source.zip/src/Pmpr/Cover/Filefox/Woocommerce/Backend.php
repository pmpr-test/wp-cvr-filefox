<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc46d83558             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\x69\156\137\151\156\151\x74", [$this, "\171\x65\171\x69\147\x75\171\145\147\x6d\155\171\x75\163\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\164\x65\162\151\141\x6c\137\155\x65\147\141\155\x65\156\165\137\146\x69\145\x6c\144\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\165\x72\x61\x6c\40\x4e\141\x6d\145", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\x74\x65\162\151\141\154")->register(); } }
