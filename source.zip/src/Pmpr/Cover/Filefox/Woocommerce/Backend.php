<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fc9e37be             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\x6e\x5f\x69\x6e\x69\x74", [$this, "\x79\145\171\x69\x67\x75\171\145\x67\155\x6d\x79\165\x73\145\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\x61\x74\145\162\x69\141\154\x5f\155\x65\147\x61\x6d\145\x6e\x75\x5f\146\151\x65\154\x64\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\x75\162\141\x6c\40\116\x61\x6d\x65", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\155\141\164\145\x72\x69\x61\154")->register(); } }
