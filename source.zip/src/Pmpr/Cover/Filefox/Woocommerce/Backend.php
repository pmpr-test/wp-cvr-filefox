<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b4a18d3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\156\x5f\151\156\x69\x74", [$this, "\171\145\171\x69\x67\x75\171\x65\147\x6d\x6d\171\165\x73\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\141\x74\x65\x72\x69\141\154\x5f\155\145\x67\141\x6d\145\x6e\x75\x5f\x66\x69\145\154\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\x75\162\x61\x6c\x20\x4e\141\x6d\145", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\x6d\141\164\145\x72\x69\x61\x6c")->register(); } }
