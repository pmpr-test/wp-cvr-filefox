<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677bbeb69d07e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\156\137\151\156\151\164", [$this, "\x79\x65\171\151\x67\165\171\145\147\155\x6d\171\x75\x73\145\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\x74\145\x72\151\x61\x6c\137\155\145\x67\141\155\x65\x6e\165\x5f\146\x69\145\154\144\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\x75\x72\x61\154\x20\116\x61\x6d\145", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\x6d\x61\x74\x65\x72\151\141\154")->register(); } }
