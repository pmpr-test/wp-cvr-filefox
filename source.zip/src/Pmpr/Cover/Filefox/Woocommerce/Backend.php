<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1cfae4ab0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\151\x6e\x5f\151\x6e\x69\164", [$this, "\x79\145\171\151\147\165\171\x65\x67\x6d\x6d\171\x75\x73\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\x74\x65\x72\151\x61\x6c\x5f\155\145\147\x61\155\145\156\165\137\x66\151\145\154\x64\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\165\162\x61\154\x20\x4e\141\155\145", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\x74\145\162\151\141\154")->register(); } }
