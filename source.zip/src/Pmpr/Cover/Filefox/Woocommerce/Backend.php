<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f98c95576             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\x6d\151\x6e\x5f\151\x6e\x69\x74", [$this, "\x79\x65\171\x69\x67\165\x79\x65\147\155\155\171\x75\163\145\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\164\x65\162\151\141\x6c\137\x6d\x65\147\141\155\x65\156\165\137\x66\151\145\x6c\144\x73")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\x6c\165\x72\x61\x6c\40\x4e\141\155\145", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\164\x65\162\151\x61\x6c")->register(); } }
