<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc22266c29             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\x69\156\x5f\x69\156\x69\x74", [$this, "\171\x65\x79\x69\147\x75\171\145\147\155\x6d\x79\165\163\x65\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\141\164\145\x72\151\x61\x6c\x5f\155\145\x67\141\155\145\x6e\165\x5f\x66\x69\x65\154\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\165\162\x61\154\x20\x4e\141\x6d\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\x74\145\162\151\141\x6c")->register(); } }
