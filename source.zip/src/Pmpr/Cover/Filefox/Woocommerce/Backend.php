<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc129dbe18             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x61\144\155\x69\x6e\137\x69\x6e\151\x74", [$this, "\x79\145\x79\151\147\x75\x79\x65\x67\x6d\x6d\x79\x75\163\x65\x61"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\x6d\141\164\x65\x72\x69\141\154\137\x6d\x65\x67\141\155\x65\156\165\137\146\x69\145\154\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\x75\162\141\154\x20\x4e\x61\x6d\x65", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\164\x65\162\151\141\154")->register(); } }
