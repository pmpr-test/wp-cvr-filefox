<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc9c93b4c7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\x6d\x69\156\137\x69\x6e\151\164", [$this, "\x79\145\x79\151\147\165\171\145\147\x6d\x6d\171\x75\x73\145\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\164\145\162\x69\x61\154\137\155\145\147\141\155\145\x6e\x75\x5f\146\151\x65\x6c\144\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\120\154\165\162\141\x6c\x20\x4e\x61\155\145", PR__CST__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\x74\145\x72\x69\141\x6c")->register(); } }
