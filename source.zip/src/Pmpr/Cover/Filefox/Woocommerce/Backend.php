<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523fd154c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\x69\x6e\x5f\x69\x6e\151\164", [$this, "\x79\145\171\x69\147\165\171\x65\147\155\x6d\x79\x75\x73\145\141"]); } public function yeyiguyegmmyusea() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $uuyucgkyusckoaeq->scyscgskcwukckyy("\155\x61\164\145\162\151\x61\x6c\x5f\x6d\145\147\141\x6d\145\156\165\x5f\x66\151\145\x6c\x64\163")->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::mmieaueggwwaokig)->gswweykyogmsyawy(__("\x50\154\x75\x72\141\x6c\40\x4e\141\x6d\145", PR__CVR__FILEFOX)))->auoaeeuwaqswggqg("\155\x61\x74\x65\162\151\x61\154")->register(); } }
