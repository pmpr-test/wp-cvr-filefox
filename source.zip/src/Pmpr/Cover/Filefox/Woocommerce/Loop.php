<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915126a65d4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\x63\x6f\x6d\x6d\145\x72\x63\145\x5f\x70\x72\x6f\x64\165\x63\x74\x5f\x6c\157\x6f\160\137\164\151\x74\x6c\x65\137\x63\154\141\163\x73\145\163", [$this, "\x61\167\x6f\x6d\x6b\x71\161\165\161\x77\x6b\x79\155\x67\167\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\x68\63\40\x6d\x62\x2d\x32\40\x6c\151\156\145\55\154\x69\155\x69\164\40\154\x69\x6e\145\55\x6c\x69\x6d\x69\x74\55\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\167\157\157\x63\x6f\155\x6d\145\x72\143\145\x2d\x70\x61\147\151\156\141\164\151\x6f\x6e" => ["\x63\x6c\x61\x73\163" => "\x64\x2d\x66\154\x65\170\40\x6a\x75\x73\x74\x69\146\171\x2d\143\x6f\x6e\164\x65\x6e\164\x2d\x63\145\156\x74\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
