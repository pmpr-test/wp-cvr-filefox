<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fdcfddc8be             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\157\157\143\157\155\x6d\145\x72\x63\x65\137\x70\162\x6f\x64\165\143\x74\x5f\x6c\157\x6f\160\137\x74\151\x74\x6c\145\137\143\x6c\141\163\x73\145\x73", [$this, "\x61\x77\x6f\x6d\153\161\161\165\161\167\x6b\x79\155\x67\167\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\x68\63\40\x6d\142\x2d\x32\40\x6c\x69\156\145\x2d\154\151\155\x69\164\x20\x6c\x69\x6e\x65\x2d\x6c\151\x6d\151\164\x2d\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\167\157\157\x63\x6f\155\155\145\x72\x63\145\55\160\x61\147\151\x6e\141\164\x69\x6f\x6e" => ["\143\154\x61\x73\163" => "\144\55\146\154\145\170\40\x6a\165\x73\164\x69\x66\171\x2d\143\157\156\x74\145\156\x74\55\143\x65\156\x74\145\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
