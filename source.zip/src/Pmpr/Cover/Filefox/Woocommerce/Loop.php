<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b4a18d3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\157\x63\x6f\155\x6d\x65\x72\143\x65\137\160\x72\157\x64\165\143\164\137\154\x6f\x6f\160\x5f\x74\151\164\x6c\x65\x5f\x63\154\141\163\163\x65\163", [$this, "\141\167\157\155\x6b\161\161\165\161\167\x6b\171\x6d\147\x77\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\63\x20\x6d\x62\x2d\62\x20\x6c\151\x6e\145\x2d\154\151\x6d\x69\x74\40\x6c\x69\156\x65\x2d\x6c\x69\x6d\x69\164\55\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\x77\x6f\157\x63\157\x6d\x6d\145\x72\x63\145\x2d\x70\x61\147\x69\156\141\x74\x69\157\x6e" => ["\143\154\x61\x73\x73" => "\144\x2d\146\154\x65\x78\x20\152\x75\163\x74\x69\146\171\x2d\x63\157\156\x74\145\x6e\164\x2d\x63\145\156\x74\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
