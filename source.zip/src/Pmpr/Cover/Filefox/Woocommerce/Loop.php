<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc9c93b4c7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\157\157\x63\157\155\x6d\x65\x72\143\145\137\160\x72\157\144\165\x63\x74\137\x6c\x6f\x6f\160\137\x74\x69\164\x6c\145\x5f\143\x6c\x61\x73\163\x65\x73", [$this, "\x61\167\x6f\x6d\x6b\x71\x71\x75\x71\167\153\x79\155\x67\x77\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\63\40\x6d\x62\55\62\40\x6c\x69\x6e\145\55\154\151\155\x69\x74\40\154\151\x6e\x65\55\x6c\x69\155\151\x74\x2d\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\167\157\x6f\143\157\155\155\145\x72\143\145\55\160\141\147\x69\x6e\141\x74\x69\x6f\x6e" => ["\x63\x6c\141\x73\163" => "\x64\55\x66\x6c\145\170\40\152\x75\163\164\x69\x66\171\55\x63\157\x6e\x74\x65\x6e\164\55\x63\145\156\x74\x65\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
