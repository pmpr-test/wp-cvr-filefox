<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1cfae4ab0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\157\143\x6f\x6d\155\x65\162\x63\x65\137\x70\162\x6f\x64\165\x63\x74\x5f\x6c\157\x6f\x70\x5f\x74\x69\164\154\145\x5f\x63\154\x61\x73\163\x65\x73", [$this, "\141\x77\x6f\155\x6b\x71\161\165\x71\167\153\x79\155\147\x77\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\x33\x20\155\142\x2d\62\40\154\x69\x6e\x65\x2d\x6c\151\x6d\x69\164\x20\154\151\x6e\145\x2d\x6c\x69\x6d\x69\164\55\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\x77\157\x6f\x63\157\155\155\145\162\x63\145\55\160\x61\x67\151\156\x61\164\x69\x6f\x6e" => ["\x63\x6c\x61\x73\163" => "\x64\x2d\146\154\x65\170\40\152\x75\x73\164\151\x66\171\55\x63\157\x6e\x74\145\x6e\x74\55\143\145\x6e\164\145\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
