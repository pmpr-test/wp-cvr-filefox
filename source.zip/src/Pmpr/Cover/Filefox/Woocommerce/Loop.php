<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d8352db942             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\x6f\143\157\155\x6d\145\162\x63\145\x5f\x70\162\157\x64\165\x63\x74\x5f\x6c\x6f\x6f\x70\x5f\x74\x69\x74\x6c\x65\137\143\154\x61\163\x73\x65\x73", [$this, "\141\167\x6f\155\x6b\x71\161\x75\161\x77\x6b\171\x6d\147\167\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\x68\63\40\x6d\x62\x2d\x32\x20\x6c\x69\x6e\145\x2d\x6c\x69\x6d\151\x74\x20\x6c\x69\156\x65\x2d\154\x69\155\x69\x74\x2d\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\167\x6f\157\x63\x6f\155\x6d\145\x72\x63\145\x2d\x70\x61\147\151\156\x61\164\151\157\x6e" => ["\x63\x6c\141\x73\163" => "\x64\55\x66\x6c\145\x78\40\x6a\x75\163\x74\x69\x66\x79\x2d\x63\x6f\x6e\x74\145\x6e\x74\55\x63\x65\x6e\164\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
