<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bcab70d793             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\157\143\x6f\155\x6d\x65\x72\x63\145\x5f\x70\x72\x6f\x64\x75\x63\x74\137\x6c\157\157\160\137\164\x69\164\x6c\145\137\x63\x6c\x61\x73\163\x65\x73", [$this, "\141\x77\157\155\153\x71\x71\x75\x71\167\153\x79\x6d\147\167\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\x33\40\155\142\55\x32\40\154\151\x6e\145\55\x6c\151\x6d\151\164\x20\x6c\x69\x6e\x65\x2d\x6c\151\155\x69\164\x2d\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\x77\157\x6f\x63\x6f\x6d\155\x65\x72\143\x65\x2d\x70\x61\x67\x69\x6e\x61\x74\151\x6f\156" => ["\x63\x6c\x61\x73\163" => "\x64\55\146\x6c\x65\x78\x20\x6a\x75\163\x74\151\146\171\x2d\143\x6f\156\164\145\x6e\x74\55\x63\145\x6e\164\x65\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
