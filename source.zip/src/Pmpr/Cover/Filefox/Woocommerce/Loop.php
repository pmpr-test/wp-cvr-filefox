<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc22266c29             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\143\x6f\155\155\145\162\x63\x65\137\x70\162\157\x64\x75\143\164\x5f\154\x6f\x6f\160\x5f\164\151\x74\154\145\x5f\143\x6c\141\163\x73\145\163", [$this, "\x61\x77\157\x6d\153\x71\x71\165\x71\167\x6b\171\x6d\x67\x77\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\x68\63\40\x6d\x62\55\x32\x20\154\151\156\x65\55\x6c\151\x6d\x69\164\x20\154\151\156\145\55\154\x69\x6d\151\x74\x2d\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\x77\157\157\143\157\x6d\155\x65\162\143\145\x2d\x70\x61\147\x69\156\x61\164\x69\157\x6e" => ["\143\154\x61\163\163" => "\x64\x2d\x66\x6c\145\170\40\152\x75\x73\x74\x69\146\171\x2d\143\157\x6e\164\x65\x6e\x74\55\143\x65\156\x74\x65\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
