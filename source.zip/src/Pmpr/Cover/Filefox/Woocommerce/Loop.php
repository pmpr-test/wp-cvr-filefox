<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677bbeb69d07e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\x6f\143\157\x6d\x6d\145\162\143\145\x5f\x70\x72\x6f\144\165\x63\x74\137\154\157\x6f\x70\x5f\x74\x69\x74\154\145\137\143\x6c\x61\x73\x73\x65\163", [$this, "\141\x77\x6f\155\x6b\x71\161\165\x71\x77\153\171\x6d\x67\x77\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\63\40\x6d\142\55\x32\x20\x6c\151\156\x65\55\154\x69\155\x69\164\40\x6c\x69\x6e\145\x2d\154\x69\x6d\x69\164\55\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\x77\x6f\x6f\x63\x6f\155\x6d\145\x72\x63\x65\x2d\x70\141\x67\x69\156\141\164\151\157\156" => ["\x63\x6c\x61\x73\x73" => "\x64\55\146\x6c\x65\x78\40\x6a\165\163\x74\151\x66\171\x2d\x63\157\x6e\164\145\x6e\x74\x2d\x63\145\156\164\x65\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
