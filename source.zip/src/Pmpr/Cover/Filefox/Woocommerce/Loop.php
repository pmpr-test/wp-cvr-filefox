<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f98c95576             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\157\x6f\143\157\155\155\145\x72\143\145\x5f\x70\x72\157\144\x75\x63\x74\x5f\x6c\x6f\x6f\160\x5f\164\x69\x74\154\145\x5f\143\x6c\x61\x73\163\145\163", [$this, "\x61\167\157\155\x6b\161\161\x75\x71\167\x6b\171\155\147\x77\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\x68\63\x20\155\142\55\62\40\x6c\x69\x6e\145\55\x6c\151\155\151\x74\40\x6c\x69\x6e\x65\x2d\x6c\x69\155\x69\164\55\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\x77\x6f\157\143\x6f\x6d\x6d\145\162\x63\145\x2d\160\141\x67\151\x6e\141\x74\151\x6f\x6e" => ["\143\154\x61\163\163" => "\x64\55\x66\x6c\x65\x78\x20\152\x75\x73\164\151\146\x79\55\x63\157\156\164\x65\156\x74\55\x63\x65\x6e\164\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
