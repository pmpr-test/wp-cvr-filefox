<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc46d83558             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\157\x6f\143\157\155\155\145\x72\x63\x65\137\160\162\x6f\x64\165\x63\x74\137\x6c\157\x6f\160\137\x74\x69\x74\x6c\x65\x5f\143\x6c\x61\x73\163\x65\163", [$this, "\x61\167\x6f\x6d\153\161\x71\x75\x71\167\153\x79\x6d\147\167\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\150\63\40\155\142\55\62\40\x6c\x69\156\145\x2d\x6c\x69\x6d\151\164\40\154\x69\x6e\x65\55\x6c\151\155\x69\x74\55\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\x77\x6f\157\143\x6f\x6d\x6d\145\x72\x63\x65\x2d\160\141\147\151\x6e\141\x74\x69\x6f\156" => ["\x63\x6c\x61\163\x73" => "\144\55\x66\x6c\x65\170\x20\152\165\163\164\x69\146\x79\55\143\157\x6e\x74\x65\156\x74\x2d\143\x65\x6e\x74\145\x72"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
