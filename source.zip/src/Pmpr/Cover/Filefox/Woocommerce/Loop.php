<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523fd154c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\157\157\143\x6f\155\155\145\x72\x63\x65\x5f\160\x72\157\144\165\143\164\x5f\x6c\x6f\157\160\x5f\164\x69\164\154\x65\x5f\143\154\x61\x73\x73\145\163", [$this, "\141\167\157\x6d\153\x71\161\x75\x71\x77\x6b\x79\x6d\147\167\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\x68\63\x20\155\142\55\x32\40\154\x69\156\x65\x2d\x6c\151\x6d\151\164\40\154\151\x6e\145\x2d\154\151\155\151\164\x2d\61"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\x77\157\x6f\x63\157\155\x6d\145\162\x63\145\55\160\x61\147\151\156\x61\x74\x69\x6f\x6e" => ["\x63\154\x61\163\163" => "\x64\55\x66\x6c\145\x78\40\x6a\x75\x73\164\151\146\x79\55\143\x6f\156\x74\145\x6e\x74\x2d\143\145\x6e\x74\x65\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
