<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc129dbe18             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\x6f\143\157\155\x6d\x65\x72\143\145\x5f\160\x72\x6f\144\x75\x63\x74\137\x6c\x6f\x6f\x70\137\x74\x69\164\154\145\x5f\x63\154\x61\163\163\145\163", [$this, "\141\167\157\155\x6b\161\161\x75\161\167\153\171\155\x67\167\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\x68\63\40\x6d\x62\x2d\x32\x20\154\151\156\x65\x2d\154\151\x6d\x69\164\x20\154\151\x6e\145\55\154\x69\x6d\x69\x74\x2d\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\56\x77\x6f\157\143\157\x6d\155\145\x72\x63\145\55\160\x61\x67\x69\156\141\x74\151\x6f\156" => ["\143\154\x61\x73\x73" => "\x64\x2d\146\154\x65\170\40\152\x75\x73\164\151\x66\171\x2d\x63\x6f\156\x74\145\156\x74\55\143\x65\156\x74\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
