<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d64d6c6e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\167\x6f\157\x63\157\x6d\x6d\145\x72\143\145\137\x70\x72\157\144\165\143\x74\137\154\157\x6f\x70\137\164\151\x74\154\145\x5f\143\x6c\x61\163\x73\x65\163", [$this, "\141\167\157\155\153\x71\x71\x75\161\167\153\x79\155\x67\167\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\150\63\x20\x6d\x62\55\62\x20\x6c\x69\x6e\x65\x2d\154\x69\155\151\x74\40\x6c\151\156\x65\x2d\x6c\151\155\x69\164\x2d\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\x77\x6f\157\x63\157\155\155\x65\162\143\x65\55\x70\141\x67\151\x6e\x61\164\x69\x6f\156" => ["\143\x6c\141\163\163" => "\144\55\x66\154\x65\x78\40\152\x75\x73\x74\151\x66\171\x2d\143\157\x6e\x74\145\156\164\55\x63\x65\156\x74\x65\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
