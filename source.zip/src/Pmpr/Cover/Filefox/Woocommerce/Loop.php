<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fc9e37be             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\x63\157\155\155\x65\x72\143\145\137\160\162\157\x64\x75\143\164\137\x6c\157\157\x70\137\164\151\164\x6c\x65\137\143\x6c\141\163\x73\x65\163", [$this, "\x61\x77\157\x6d\153\161\x71\x75\x71\167\153\x79\x6d\x67\167\x69"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\40\150\63\40\155\142\55\62\40\154\151\156\145\x2d\x6c\x69\x6d\x69\164\40\x6c\x69\x6e\145\x2d\x6c\151\155\x69\x74\55\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\167\157\157\x63\157\155\155\x65\162\143\145\55\160\x61\147\x69\156\x61\164\151\x6f\156" => ["\143\154\x61\163\163" => "\x64\x2d\146\154\145\x78\x20\x6a\165\x73\x74\151\146\x79\55\143\x6f\156\164\145\156\164\x2d\143\x65\x6e\x74\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
