<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030ceec9a8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Woocommerce; class Loop extends Template { public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x6f\157\143\x6f\x6d\x6d\145\x72\x63\145\x5f\160\x72\157\144\x75\143\164\x5f\x6c\157\157\160\137\x74\151\x74\x6c\x65\x5f\143\154\141\163\x73\145\x73", [$this, "\141\x77\157\x6d\153\161\161\x75\161\x77\153\171\x6d\x67\167\151"]); } public function awomkqquqwkymgwi($cmkqisoeyioisqaw) { return "{$cmkqisoeyioisqaw}\x20\150\x33\x20\155\142\x2d\x32\40\x6c\151\x6e\145\55\x6c\151\155\151\164\40\x6c\x69\x6e\x65\55\x6c\x69\x6d\151\x74\55\x31"; } public function ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea = [], $ugugagoguiycqeys = []) : array { switch ($ymqmyyeuycgmigyo) { case self::owyuwqeuiuwkwyye: $ugugagoguiycqeys = ["\x2e\167\x6f\157\143\x6f\155\x6d\x65\x72\x63\145\x2d\160\x61\147\x69\156\x61\164\x69\157\156" => ["\143\154\x61\163\163" => "\144\55\146\x6c\x65\x78\40\x6a\165\163\x74\x69\x66\171\55\x63\157\x6e\164\145\156\x74\x2d\x63\x65\x6e\x74\145\162"]]; break; } return parent::ikckqoqkgcewiwcq($ymqmyyeuycgmigyo, $aqykuigiuwmmcieu, $ymkomoccmymcoiea, $ugugagoguiycqeys); } }
