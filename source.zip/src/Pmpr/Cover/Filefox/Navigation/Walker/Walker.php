<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1cfae4ab0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; class Walker extends baseClass { use CommonTrait; protected string $elTag = "\x64\x69\x76"; protected string $lvlTag = "\144\151\166"; }
