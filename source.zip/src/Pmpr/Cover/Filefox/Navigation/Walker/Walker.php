<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b6ff7282bad             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; class Walker extends baseClass { use CommonTrait; protected string $elTag = 'div'; protected string $lvlTag = 'div'; }
