<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030ceec9a8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Navigation\Walker; use Pmpr\Common\Cover\Navigation\Walker as BaseClass; use Pmpr\Cover\Filefox\Traits\CommonTrait; class Walker extends baseClass { use CommonTrait; protected string $elTag = "\144\151\x76"; protected string $lvlTag = "\x64\151\x76"; }
