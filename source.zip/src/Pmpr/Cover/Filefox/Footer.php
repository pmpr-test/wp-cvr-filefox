<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc9c93b4c7             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x70\137\x66\157\157\164\145\162", [$this, "\x79\147\153\x63\x65\153\x71\x6b\x65\151\171\145\171\x73\x71\151"])->qcsmikeggeemccuu("\x77\151\x64\147\x65\x74\x73\x5f\x69\156\151\164", [$this, "\x79\155\141\x79\167\143\x63\141\151\163\143\163\155\x73\151\153"]); $this->waqewsckuayqguos("\162\145\x6e\144\x65\162\x5f\146\157\x6f\x74\145\x72", [$this, "\162\x65\x6e\144\x65\162"])->waqewsckuayqguos("\162\145\x6e\144\145\162\x5f\163\151\147\x6e\x61\164\165\162\145", [$this, "\141\x79\155\161\163\153\155\167\x73\165\x77\x6f\x63\x73\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\145\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
