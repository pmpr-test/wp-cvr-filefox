<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6773f98c95576             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\137\x66\x6f\x6f\164\x65\x72", [$this, "\x79\x67\153\143\x65\153\161\x6b\x65\151\171\145\x79\163\x71\x69"])->qcsmikeggeemccuu("\x77\151\144\147\x65\x74\x73\x5f\151\156\x69\164", [$this, "\x79\155\x61\x79\x77\143\143\x61\x69\163\143\x73\x6d\x73\151\153"]); $this->waqewsckuayqguos("\x72\x65\156\x64\145\162\x5f\146\157\x6f\x74\x65\162", [$this, "\x72\x65\156\144\145\x72"])->waqewsckuayqguos("\162\x65\156\x64\x65\162\x5f\163\151\147\x6e\x61\164\165\x72\145", [$this, "\x61\x79\x6d\x71\x73\x6b\x6d\x77\163\165\167\157\143\x73\x6d\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\156\144\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
