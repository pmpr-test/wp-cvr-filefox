<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915126a65d4             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\x5f\x66\x6f\157\x74\145\162", [$this, "\171\147\x6b\x63\145\153\161\153\x65\151\171\x65\x79\x73\161\x69"])->qcsmikeggeemccuu("\x77\x69\x64\x67\x65\x74\163\x5f\x69\156\151\x74", [$this, "\171\x6d\x61\171\167\143\143\x61\x69\x73\143\x73\155\x73\151\153"]); $this->waqewsckuayqguos("\x72\x65\x6e\144\x65\162\137\146\157\157\164\x65\x72", [$this, "\x72\x65\x6e\144\x65\x72"])->waqewsckuayqguos("\x72\x65\x6e\144\x65\162\x5f\163\151\x67\156\x61\164\x75\x72\x65", [$this, "\141\171\155\161\x73\153\155\x77\x73\165\x77\157\x63\163\155\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
