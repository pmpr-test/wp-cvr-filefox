<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc46d83558             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\137\146\x6f\157\x74\145\162", [$this, "\171\x67\153\x63\x65\153\x71\153\145\151\171\145\x79\x73\161\151"])->qcsmikeggeemccuu("\x77\x69\144\147\145\x74\163\137\151\156\151\x74", [$this, "\x79\x6d\x61\x79\167\x63\143\141\151\163\x63\163\155\163\151\x6b"]); $this->waqewsckuayqguos("\x72\x65\x6e\x64\x65\162\x5f\x66\157\x6f\164\145\x72", [$this, "\x72\x65\156\x64\145\x72"])->waqewsckuayqguos("\162\x65\x6e\144\x65\x72\x5f\x73\151\147\156\x61\x74\165\162\x65", [$this, "\x61\171\x6d\x71\x73\153\155\x77\163\165\167\x6f\143\x73\x6d\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\x64\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
