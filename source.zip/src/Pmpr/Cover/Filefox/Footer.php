<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523fd154c             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\137\146\157\x6f\164\145\x72", [$this, "\x79\147\153\143\x65\153\x71\x6b\x65\151\171\145\x79\163\161\x69"])->qcsmikeggeemccuu("\167\151\x64\147\x65\x74\x73\x5f\151\156\151\x74", [$this, "\171\x6d\x61\x79\x77\x63\143\x61\151\x73\143\163\x6d\x73\151\153"]); $this->waqewsckuayqguos("\x72\x65\156\x64\x65\x72\x5f\x66\x6f\x6f\x74\145\162", [$this, "\162\x65\156\x64\145\x72"])->waqewsckuayqguos("\x72\x65\156\x64\x65\162\137\163\151\x67\x6e\x61\x74\x75\162\145", [$this, "\141\x79\155\x71\x73\153\155\167\x73\x75\x77\157\x63\x73\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\156\144\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
