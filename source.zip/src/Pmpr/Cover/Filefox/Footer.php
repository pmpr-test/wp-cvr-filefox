<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fdcfddc8be             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\137\146\157\157\x74\x65\x72", [$this, "\x79\147\x6b\143\x65\153\x71\x6b\145\151\171\145\171\x73\161\151"])->qcsmikeggeemccuu("\x77\151\144\x67\145\164\x73\137\x69\156\x69\x74", [$this, "\171\155\x61\171\x77\143\143\x61\x69\x73\143\163\155\x73\x69\x6b"]); $this->waqewsckuayqguos("\162\145\156\144\145\162\137\146\x6f\157\x74\x65\162", [$this, "\x72\145\156\144\x65\162"])->waqewsckuayqguos("\x72\145\156\144\x65\x72\x5f\163\x69\x67\x6e\x61\164\165\162\x65", [$this, "\x61\x79\x6d\161\x73\x6b\x6d\x77\163\x75\167\x6f\143\163\155\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\x64\145\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
