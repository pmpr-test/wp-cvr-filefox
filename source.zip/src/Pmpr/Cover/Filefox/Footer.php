<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fc9e37be             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\x5f\x66\x6f\x6f\x74\x65\162", [$this, "\x79\147\x6b\143\145\153\x71\x6b\145\x69\171\145\171\163\x71\x69"])->qcsmikeggeemccuu("\167\x69\144\147\145\x74\x73\x5f\x69\156\151\164", [$this, "\171\155\x61\171\x77\x63\x63\141\151\163\x63\x73\155\x73\151\153"]); $this->waqewsckuayqguos("\x72\x65\x6e\x64\145\162\x5f\146\x6f\x6f\x74\145\162", [$this, "\x72\145\x6e\x64\x65\162"])->waqewsckuayqguos("\162\x65\x6e\x64\145\162\137\x73\x69\147\156\x61\164\x75\162\145", [$this, "\141\171\155\161\163\x6b\155\x77\x73\x75\x77\157\x63\163\155\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\156\144\145\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
