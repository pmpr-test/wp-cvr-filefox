<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677d8352db942             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\137\146\x6f\157\164\x65\162", [$this, "\171\x67\x6b\x63\145\x6b\161\x6b\145\151\x79\x65\171\163\x71\x69"])->qcsmikeggeemccuu("\167\x69\x64\147\x65\164\163\137\x69\x6e\x69\x74", [$this, "\171\x6d\141\171\x77\x63\x63\141\151\163\x63\x73\155\x73\x69\x6b"]); $this->waqewsckuayqguos("\162\x65\x6e\x64\x65\162\137\x66\x6f\157\164\145\162", [$this, "\162\x65\x6e\144\x65\162"])->waqewsckuayqguos("\x72\145\x6e\x64\x65\162\x5f\x73\151\147\156\141\164\165\162\145", [$this, "\x61\171\155\161\x73\x6b\155\167\x73\165\x77\157\143\x73\x6d\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\156\x64\145\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
