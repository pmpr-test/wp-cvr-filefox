<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc22266c29             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\137\x66\x6f\157\164\145\x72", [$this, "\x79\x67\153\x63\x65\153\x71\x6b\x65\x69\x79\x65\171\x73\x71\x69"])->qcsmikeggeemccuu("\x77\x69\144\147\145\x74\x73\x5f\151\x6e\x69\x74", [$this, "\171\x6d\141\x79\167\143\143\x61\x69\163\143\x73\155\x73\151\153"]); $this->waqewsckuayqguos("\162\145\156\x64\145\x72\x5f\x66\x6f\x6f\164\145\162", [$this, "\x72\145\x6e\x64\145\x72"])->waqewsckuayqguos("\x72\x65\x6e\144\x65\162\137\163\x69\147\x6e\141\164\165\x72\x65", [$this, "\141\x79\155\x71\163\153\155\x77\163\x75\167\x6f\143\163\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\144\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
