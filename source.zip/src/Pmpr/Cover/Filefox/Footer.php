<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030ceec9a8             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\x70\x5f\x66\157\x6f\x74\x65\x72", [$this, "\x79\147\153\x63\x65\153\x71\153\145\x69\171\x65\171\x73\161\151"])->qcsmikeggeemccuu("\x77\151\x64\147\145\x74\x73\x5f\x69\156\151\164", [$this, "\171\x6d\141\171\x77\143\143\x61\x69\163\143\163\x6d\163\x69\x6b"]); $this->waqewsckuayqguos("\x72\145\156\x64\x65\162\137\x66\x6f\157\164\x65\x72", [$this, "\162\x65\156\x64\145\162"])->waqewsckuayqguos("\162\x65\156\x64\145\x72\x5f\x73\x69\x67\156\141\164\165\162\145", [$this, "\141\171\x6d\x71\163\153\155\x77\x73\x75\x77\x6f\x63\163\x6d\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\144\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
