<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bc129dbe18             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\x5f\146\x6f\x6f\164\145\x72", [$this, "\x79\x67\153\143\145\153\x71\x6b\x65\151\171\145\x79\163\x71\x69"])->qcsmikeggeemccuu("\167\151\144\x67\145\164\x73\137\151\x6e\x69\164", [$this, "\x79\x6d\x61\x79\x77\x63\143\141\x69\x73\x63\163\x6d\163\x69\x6b"]); $this->waqewsckuayqguos("\162\145\156\x64\x65\162\x5f\x66\x6f\x6f\164\145\x72", [$this, "\162\145\x6e\144\x65\x72"])->waqewsckuayqguos("\x72\145\156\x64\145\162\137\x73\151\x67\156\x61\164\165\162\145", [$this, "\x61\x79\x6d\x71\163\153\x6d\x77\163\165\x77\157\x63\x73\155\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\156\x64\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
