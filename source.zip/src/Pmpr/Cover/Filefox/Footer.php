<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d64d6c6e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\137\x66\157\157\164\145\162", [$this, "\x79\147\153\x63\145\153\x71\x6b\x65\151\171\145\171\x73\161\x69"])->qcsmikeggeemccuu("\167\x69\144\x67\145\164\163\137\x69\x6e\x69\x74", [$this, "\171\x6d\141\171\167\x63\143\x61\151\x73\143\163\155\x73\x69\x6b"]); $this->waqewsckuayqguos("\162\x65\156\x64\145\162\137\146\157\x6f\164\145\162", [$this, "\x72\x65\156\144\145\x72"])->waqewsckuayqguos("\162\x65\x6e\144\145\x72\137\x73\x69\147\x6e\141\x74\x75\162\145", [$this, "\x61\171\x6d\161\163\153\x6d\167\163\x75\x77\157\143\x73\x6d\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\x64\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
