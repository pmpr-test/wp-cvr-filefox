<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4b4a18d3             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\x70\x5f\146\x6f\x6f\x74\x65\x72", [$this, "\x79\147\153\x63\x65\153\x71\153\x65\x69\x79\x65\x79\x73\x71\x69"])->qcsmikeggeemccuu("\167\151\x64\147\145\164\x73\137\151\x6e\151\164", [$this, "\x79\155\x61\171\167\x63\143\141\x69\163\143\x73\155\x73\x69\x6b"]); $this->waqewsckuayqguos("\x72\x65\156\x64\145\162\137\146\x6f\x6f\x74\145\162", [$this, "\x72\145\156\x64\x65\162"])->waqewsckuayqguos("\x72\145\156\x64\145\x72\x5f\163\151\147\x6e\141\x74\165\162\x65", [$this, "\x61\x79\x6d\x71\163\x6b\x6d\167\163\x75\x77\x6f\x63\163\x6d\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\144\145\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
