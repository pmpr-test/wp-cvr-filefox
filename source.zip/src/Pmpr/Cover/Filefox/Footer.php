<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1cfae4ab0             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\x5f\x66\x6f\157\x74\145\x72", [$this, "\171\147\153\x63\x65\x6b\161\153\145\x69\171\x65\171\x73\161\x69"])->qcsmikeggeemccuu("\x77\x69\x64\147\x65\x74\x73\137\x69\156\x69\164", [$this, "\171\155\141\171\x77\x63\143\x61\151\163\143\163\x6d\163\151\x6b"]); $this->waqewsckuayqguos("\x72\x65\156\144\x65\162\137\x66\157\x6f\164\145\x72", [$this, "\x72\x65\156\144\x65\162"])->waqewsckuayqguos("\x72\145\156\x64\145\162\137\163\x69\x67\156\x61\x74\165\162\145", [$this, "\141\x79\x6d\161\163\x6b\x6d\x77\x73\165\167\157\143\163\155\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\x69\x6e\144\145\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
