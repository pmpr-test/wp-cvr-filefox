<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677bbeb69d07e             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\167\160\x5f\x66\157\x6f\x74\x65\162", [$this, "\x79\x67\x6b\x63\145\x6b\161\x6b\145\151\171\145\x79\x73\161\x69"])->qcsmikeggeemccuu("\167\x69\144\x67\145\x74\163\x5f\151\x6e\151\164", [$this, "\x79\155\x61\x79\167\143\143\141\x69\x73\143\x73\155\x73\151\x6b"]); $this->waqewsckuayqguos("\x72\145\x6e\x64\x65\162\137\x66\157\157\164\145\162", [$this, "\162\145\156\144\x65\x72"])->waqewsckuayqguos("\162\x65\x6e\144\145\x72\137\x73\151\147\156\141\x74\x75\162\145", [$this, "\x61\171\155\x71\x73\x6b\155\x77\x73\165\x77\157\143\x73\155\153"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\144\x65\x78"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
