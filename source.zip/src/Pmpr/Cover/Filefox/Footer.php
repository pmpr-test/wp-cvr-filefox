<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bcab70d793             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class Footer extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x77\160\x5f\146\157\x6f\164\x65\162", [$this, "\x79\x67\x6b\143\x65\153\x71\153\x65\151\171\145\171\x73\x71\x69"])->qcsmikeggeemccuu("\167\151\x64\147\145\x74\x73\x5f\x69\x6e\x69\164", [$this, "\171\155\141\171\x77\x63\x63\x61\x69\163\143\163\155\163\x69\x6b"]); $this->waqewsckuayqguos("\x72\145\x6e\x64\x65\162\x5f\x66\x6f\x6f\164\145\162", [$this, "\162\x65\156\144\145\162"])->waqewsckuayqguos("\162\x65\156\144\x65\x72\x5f\163\x69\147\156\141\164\165\162\145", [$this, "\x61\x79\155\161\x73\x6b\x6d\167\x73\x75\x77\157\x63\x73\x6d\x6b"]); } public function render() { echo $this->iuygowkemiiwqmiw("\151\x6e\x64\x65\170"); } public function ygkcekqkeiyeysqi() { } public function ymaywccaiscsmsik() { } }
