<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b7a85a707cd             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; use Pmpr\Common\Foundation\Interfaces\Constants; class Single extends Container { public function wigskegsqequoeks() { $this->waqewsckuayqguos('render_post_author', [$this, 'vkoussmggmyoieey'], 10, 2); } public function vkoussmggmyoieey($post, array $ywmkwiwkosakssii = []) { $ywmkwiwkosakssii = $this->caokeucsksukesyo()->gyecsegqciqykomu()->ckscqqquyskscaaw($ywmkwiwkosakssii, ['avatar_size' => 36]); $seumokooiykcomco = $this->caokeucsksukesyo()->ayueggmoqeeukqmq(); $qaqgaqikqmcmukem = $seumokooiykcomco->mguqscccckuywsya($post); if ($qaqgaqikqmcmukem) { $yoiguusocukqeayg = $this->caokeucsksukesyo()->issssuygyewuaswa(); $this->iuygowkemiiwqmiw('common/single/author', ['avatar_size' => $ywmkwiwkosakssii['avatar_size'], Constants::auqoykcmsiauccao => $seumokooiykcomco->qkweigiqsaaigqau($qaqgaqikqmcmukem), Constants::NAME => $yoiguusocukqeayg->ygwimyogyaqgumam($qaqgaqikqmcmukem), Constants::ceaooaoacwwcuoqm => $yoiguusocukqeayg->quasyaqmmikeyoag($qaqgaqikqmcmukem, $ywmkwiwkosakssii['avatar_size'])], [Constants::qaacaqioeyiuakeu => true]); } } }
