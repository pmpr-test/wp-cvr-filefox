<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e5a4f86e76d             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page\Material; use Pmpr\Common\Foundation\Frontend\TaxonomyEndPoint; use Pmpr\Common\Foundation\Interfaces\Constants; class Contact extends TaxonomyEndPoint { public function qiccuiwooiquycsg() { $this->ykuiyscecakwkmui(Constants::oeeqisiiqoswqqmy)->gecckeoacskeskii(__('Contact', PR__CVR__FILEFOX)); parent::qiccuiwooiquycsg(); } }
