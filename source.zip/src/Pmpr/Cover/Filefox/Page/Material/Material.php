<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ddc43417993             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Page\Material; use Pmpr\Cover\Filefox\Container; class Material extends Container { public function mameiwsayuyquoeq() { Home::symcgieuakksimmu(); Store::symcgieuakksimmu(); About::symcgieuakksimmu(); Contact::symcgieuakksimmu(); } }
