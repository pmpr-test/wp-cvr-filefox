<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c2b32200403             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Component\Module; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Button; use Pmpr\Common\Foundation\FormGenerator\Frontend\Field\Textarea; use Pmpr\Cover\Filefox\Container; class Rating extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('rating_feedback_form_fields', [$this, 'mecgaacyquougueg']); } public function mecgaacyquougueg($ikgwqyuyckaewsow) { if (is_array($ikgwqyuyckaewsow) && $ikgwqyuyckaewsow) { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { if ($aiowsaccomcoikus instanceof Textarea) { $aiowsaccomcoikus->uqamgcwceyasmoki(5); $aiowsaccomcoikus->kakecegieeqyyayu()->qigsyyqgewgskemg('mb-3'); } else { if ($aiowsaccomcoikus instanceof Button) { $aiowsaccomcoikus->kakecegieeqyyayu()->qigsyyqgewgskemg('d-flex justify-content-end'); } } } } return $ikgwqyuyckaewsow; } }
