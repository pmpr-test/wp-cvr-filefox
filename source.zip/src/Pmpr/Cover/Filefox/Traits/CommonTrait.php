<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681a82fd20d56             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox\Traits; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use WC_Product; trait CommonTrait { public function ouqouwemcymaqoqc($mwwsoasauceiwsmk) { $ucicuwcaawugkseg = 0; $gkyciwoiiisgywcs = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc(); if ('material' === $gkyciwoiiisgywcs->get($mwwsoasauceiwsmk, Constants::ckmqoekmugkggeym)) { $ucicuwcaawugkseg = $gkyciwoiiisgywcs->get($mwwsoasauceiwsmk, Constants::eggygikowgywcayq); } return $ucicuwcaawugkseg; } public function uuiqowweqqewoysu(?string $uusmaiomayssaecw = '') { $ykiyyumywksqcisg = ['library' => IconInterface::eyikeaawgqmqgqkw, 'dashboard' => IconInterface::ygcmqmkcsymeucoq, 'orders' => IconInterface::goqumcwkcuygcaui, 'downloads' => IconInterface::msyqysqykouywsua, 'edit-address' => IconInterface::wykikkeyisimsmyy, 'payment-methods' => IconInterface::acciucugwcskkwmi, 'edit-account' => IconInterface::wqqgoiyyqicsycmm, 'customer-logout' => IconInterface::ygmsyksiyocgyyke]; return $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($ykiyyumywksqcisg, $uusmaiomayssaecw, IconInterface::wukkqukiiuuoyiiy); } }
