<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f85fa2e3a             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; class TableOfContent extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('table_of_content_anchor_element', [$this, 'eouggeeuoyiwsyiw'])->aqaqisyssqeomwom('table_of_content_anchor_attributes', [$this, 'qagycogekeuewkwq']); } public function eouggeeuoyiwsyiw($kqywgoqsmuswammk) { if ($kqywgoqsmuswammk === 'a') { $kqywgoqsmuswammk = 'span'; } return $kqywgoqsmuswammk; } public function qagycogekeuewkwq($siquossayskcwkea) { if (isset($siquossayskcwkea['href'])) { $siquossayskcwkea = $this->caokeucsksukesyo()->wgqqgewcmcemoewo()->sueyawuweyoqyeaq($siquossayskcwkea, ['class' => 'as-link', 'data-type' => 'scroll-to', 'data-offset' => 30, 'data-target' => $siquossayskcwkea['href']]); unset($siquossayskcwkea['href']); } return $siquossayskcwkea; } }
