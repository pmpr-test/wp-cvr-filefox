<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68d3d23240c31             |
    |_______________________________________|
*/
 namespace Pmpr\Cover\Filefox; use Pmpr\Common\Foundation\Interfaces\Constants; class Editor extends Container { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom('editor_table_classes', [$this, 'ucqemmuigmmqcmiy']); } public function ucqemmuigmmqcmiy($cmkqisoeyioisqaw) { $cmkqisoeyioisqaw[] = [Constants::qescuiwgsyuikume => __('Light Header Table', PR__CVR__FILEFOX), Constants::ciyoccqkiamemcmm => 'table thead-light-primary']; $cmkqisoeyioisqaw[] = [Constants::qescuiwgsyuikume => __('Light Header Striped Table', PR__CVR__FILEFOX), Constants::ciyoccqkiamemcmm => 'table table-striped table-hover thead-light-primary']; return $cmkqisoeyioisqaw; } }
