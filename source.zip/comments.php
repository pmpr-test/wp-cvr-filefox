<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68d3b95e3decb             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
