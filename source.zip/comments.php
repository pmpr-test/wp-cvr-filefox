<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680567a200a9b             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
