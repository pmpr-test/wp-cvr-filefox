<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169e2758346             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
