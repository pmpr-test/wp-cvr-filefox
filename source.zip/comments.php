<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e5a57200597             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
