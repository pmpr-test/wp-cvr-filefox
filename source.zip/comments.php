<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ddc70de52bb             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
