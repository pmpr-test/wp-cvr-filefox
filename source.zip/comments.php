<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687f56e04d12f             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
