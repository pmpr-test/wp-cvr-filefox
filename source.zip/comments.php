<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6ec8f70c             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
