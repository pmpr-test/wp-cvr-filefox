<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4dd2bdb92b             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
