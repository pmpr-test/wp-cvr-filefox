<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68db1d3824196             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
