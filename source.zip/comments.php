<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68db0a0b0ac1c             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
