<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a661dae9442             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
