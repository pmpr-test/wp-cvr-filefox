<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a724774e524             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
