<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c2c52f0f437             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
