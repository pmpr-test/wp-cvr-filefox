<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68db150a9d098             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
