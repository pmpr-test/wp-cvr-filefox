<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a7294cbe901             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
