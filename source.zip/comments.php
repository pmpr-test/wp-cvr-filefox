<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68db0b1bdb300             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
