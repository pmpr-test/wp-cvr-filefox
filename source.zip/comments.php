<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a716112116c             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
