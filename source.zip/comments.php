<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687eacd92ed32             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
