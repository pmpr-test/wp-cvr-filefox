<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6843eaa10f854             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
