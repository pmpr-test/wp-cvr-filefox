<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e9a8db28034             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
