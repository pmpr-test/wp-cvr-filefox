<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc6c807079             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
