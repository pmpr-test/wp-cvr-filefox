<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68d3d23240c31             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
