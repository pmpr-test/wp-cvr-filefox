<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68daeb6db14f7             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
