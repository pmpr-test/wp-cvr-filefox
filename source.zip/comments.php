<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c83a3e27327             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
