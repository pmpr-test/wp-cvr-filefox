<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e166ca98632             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
