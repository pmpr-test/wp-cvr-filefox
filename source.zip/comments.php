<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cf32909ca5f             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
