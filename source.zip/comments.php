<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6884a910b7cb6             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
