<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dbbe397f9fb             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
