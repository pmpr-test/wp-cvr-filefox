<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6838de08eab3a             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
