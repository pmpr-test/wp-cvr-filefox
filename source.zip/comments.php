<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687e31c5b68b2             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
