<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ddc1b93193a             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
