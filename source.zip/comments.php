<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67cf2e1fea48f             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
