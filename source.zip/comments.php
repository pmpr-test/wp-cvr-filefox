<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dbbdcc92947             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
