<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c839b8d381d             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
