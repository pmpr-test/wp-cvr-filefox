<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e598c84128e             |
    |_______________________________________|
*/
 pmpr_do_action('render_comments');
